# SEP Relay Bundle

## Contents
- `sep_relay_runner.py`：纯 Python 搬运入口
- `script/get_SEP_Header.py`：SEP 区块头抓取与编码脚本
- `data/dev/Manager.address`、`data/test/Manager.address`：管理合约地址

## Steps
1. 安装依赖：`pip install -r requirements.txt`
2. 将 `.env.example` 复制为 `.env` 并填写参数
3. 在解压目录执行：`python sep_relay_runner.py --env dev --interval 5`

## Notes
- 解压后的当前目录就是运行根目录
- 不再依赖 `forge`、`foundry.toml`、`src/`、`lib/`
- 脚本会持续轮询，直到手动停止
